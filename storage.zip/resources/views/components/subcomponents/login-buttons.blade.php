<div class="login-buttons">
    <a class="login-button" href="/login">LOG IN</a>
    <a class="signin-button" href="/register">SIGN UP</a>
</div>
<div class="old-reddit-link">
    <a href="#"><i class="fas fa-external-link-alt"></i>Visit Old Reddit</a>
</div>
<button class="user-options">
    <i class="fas fa-user-alt usr-img"></i>
    <i class="fas fa-sort-down usr-open"></i>
</button>