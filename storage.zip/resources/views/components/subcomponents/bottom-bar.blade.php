<div class="bottom-header">
    <div class="wrapper">
        <div class="view-options">
            <span class="option-title">View</span>
            <div class="view-opt-icons">
                <i class="fas fa-th selected"></i>
                <i class="fas fa-th-large deselected"></i>
                <i class="fas fa-th-list deselected"></i>
            </div>
        </div>
        <div class="sort-options">
            <span class="option-title">Sort</span>
            <div class="bh-filter-type bh-filter-list">
                <i class="fas fa-fire flame"></i>
                <span class="sort-option">Hot</span>
                <i class="fas fa-sort-down list-arrow"></i>
            </div>
            <div class="bh-filter-location bh-filter-list">
                <span class="sort-option">Canada</span>
                <i class="fas fa-sort-down list-arrow"></i>
            </div>
        </div>
    </div>
</div>