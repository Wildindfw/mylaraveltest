<header>
    @include('components.subcomponents.top-bar')
    @include('components.subcomponents.bottom-bar')
</header>