<div class="footer-post">
    <div class="fp-top">
        <div class="fpt-left">
            <a href="#">About</a>
            <a href="#">Careers</a>
            <a href="#">Press</a>
        </div>
        <div class="fpt-center">
            <a href="#">Advertise</a>
            <a href="#">Blog</a>
            <a href="#">Help</a>
        </div>
        <div class="fpt-right">
            <a href="#">The Reddit App</a>
            <a href="#">Reddit Gold</a>
            <a href="#">Reddit Premium</a>
            <a href="#">Reddit Gifts</a>
        </div>
    </div>
    <div class="fp-bottom">
        <div class="link-row">
            <a href="#">Content Policy</a><span>|</span><a href="#">Privacy Policy</a>
        </div>
        <div class="link-row">
            <a href="#">User Agreement</a><span>|</span><a href="#">Mod Policy</a>
        </div>
        <div class="link-row">
            <span>&copy; 2018 Reddit, Inc. All rights reserved</span>
        </div>
    </div>
</div>