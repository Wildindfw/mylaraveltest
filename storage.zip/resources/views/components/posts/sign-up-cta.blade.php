<div class="sign-up-cta">
    <h1>Join the discussion</h1>
    <span>Comment and be a part of what the internet is talking about.</span>
    <a class="cta-button" href="/register">Become a Redditor</a>
    <button class="cta-close-button"><i class="fas fa-times"></i></button>
</div>