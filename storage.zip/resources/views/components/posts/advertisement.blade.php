<div class="advertisement-post">
    <span>Advertisement</span>
    <div class="ad"></div>
</div>