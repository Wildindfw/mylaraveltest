{{-- FIXME: In the future, this could use a better name --}}
<div class="subreddit-post">
    <div class="sr-header">
        <div class="sr-top-img"></div>
        <div class="sr-title"><img class="sr-alien" src="https://www.redditstatic.com/desktop2x/img/id-cards/snoo-home@2x.png" alt=""><span>r/popular</span></div>
    </div>
    <div class="sr-content">The best posts on Reddit for you, pulled from the most active communities on Reddit. Check here to see the most shared,
        upvoted, and commented content on the internet.</div>
    <a class="sr-button" href="/post/r/popular">Create Post</a>
</div>