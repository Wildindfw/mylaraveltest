<div class="reddit-premium-post">
    <i class="fas fa-shield-alt rp-shield"></i>
    <div class="rp-text">
        <span class="rp-title">Reddit Premium</span>
        <span class="rp-text">Ads-free browsing</span>
    </div>
    <button class="rp-button">Get Premium</button>
</div>